You need the package Scrypt from Procurses repo to use these scripts.
Place these at `/var/mobile/Library/Filza/scripts`